package es.ucm.fdi.ici.c2223.practica1.grupo08;

import java.util.EnumMap;
import java.util.Random;

import pacman.controllers.GhostController;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

public class Ghosts extends GhostController {
	private EnumMap<GHOST, MOVE> moves = new EnumMap<GHOST, MOVE>(GHOST.class);
	private Random rnd = new Random();
	private MOVE[] allMoves = MOVE.values();
	
	public Ghosts() {
		super();
		setName("Ghosts08");
		setTeam("Team08");
	}

	private boolean pacmanCloseToPPill(Game game, int limit) {
		boolean check = false;
		int pacmanNode = game.getPacmanCurrentNodeIndex();
		if (game.getActivePillsIndices().length == 0
				|| game.getClosestNodeIndexFromNodeIndex(pacmanNode, game.getActivePowerPillsIndices(), DM.PATH) == -1)
			return false;
		if ((game.getShortestPathDistance(
				game.getClosestNodeIndexFromNodeIndex(pacmanNode, game.getActivePowerPillsIndices(), DM.PATH),
				pacmanNode)) < limit) {
			if (game.getShortestPathDistance(
					game.getClosestNodeIndexFromNodeIndex(pacmanNode, game.getActivePowerPillsIndices(), DM.PATH),
					pacmanNode) == 0) {
				check = false;
			} else {
				check = true;
			}
		}
		return check;
	}

	private MOVE getOpposingMove(MOVE move) {
		MOVE opposingMove = MOVE.NEUTRAL;
		switch (move) {
		case DOWN:
			opposingMove = MOVE.UP;
			break;
		case UP:
			opposingMove = MOVE.DOWN;
			break;
		case RIGHT:
			opposingMove = MOVE.LEFT;
			break;
		case LEFT:
			opposingMove = MOVE.RIGHT;
			break;
		case NEUTRAL:
			opposingMove = MOVE.NEUTRAL;
			break;
		}
		return opposingMove;
	}

	private MOVE nextMoveNoRepeatGhost(Game game, MOVE move, GHOST thisGhost, int limit) {
		MOVE noRepeatedMove = game.getNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(thisGhost),
				game.getPacmanCurrentNodeIndex(), DM.PATH);
		if (game.getDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(thisGhost),
				DM.PATH) < limit) {
			noRepeatedMove = game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(thisGhost),
					game.getPacmanCurrentNodeIndex(), getOpposingMove(move), DM.PATH);
		}
		return noRepeatedMove;
	}

	@Override
	public EnumMap<GHOST, MOVE> getMove(Game game, long timeDue) {
		for (GHOST ghostType : GHOST.values()) {
			if (game.doesGhostRequireAction(ghostType)) {
				if (game.isGhostEdible(ghostType) || pacmanCloseToPPill(game, 50)) {
					moves.put(ghostType,
							game.getApproximateNextMoveAwayFromTarget(game.getGhostCurrentNodeIndex(ghostType),
									game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType), DM.PATH));
				}

				for (GHOST g : GHOST.values()) {
					if (g != ghostType) {
						if (game.getShortestPathDistance(game.getGhostCurrentNodeIndex(g),
								game.getGhostCurrentNodeIndex(ghostType), game.getGhostLastMoveMade(ghostType)) < 10) {
							moves.put(g,
									game.getApproximateNextMoveAwayFromTarget(game.getGhostCurrentNodeIndex(ghostType),
											game.getGhostCurrentNodeIndex(g), game.getGhostLastMoveMade(ghostType), DM.PATH));
						}
					}
				}
			} else {
				if (ghostType == GHOST.BLINKY) {
					moves.put(ghostType, game.getNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
							game.getPacmanCurrentNodeIndex(), DM.PATH));
				}
				if (ghostType == GHOST.INKY) {
					if (game.getGhostLastMoveMade(GHOST.BLINKY) != null) {

						if (game.getNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
								game.getPacmanCurrentNodeIndex(), DM.PATH) == game.getPacmanLastMoveMade()) {
							moves.put(ghostType,
									nextMoveNoRepeatGhost(game, game.getPacmanLastMoveMade(), ghostType, 30));
						} else {
							moves.put(ghostType, game.getNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
									game.getPacmanCurrentNodeIndex(), DM.PATH));
						}
					}
				} else {
					moves.put(ghostType,
							game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
									game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType), DM.PATH));

				}
				if (ghostType == GHOST.PINKY) {
					if (game.getShortestPathDistance(game.getGhostCurrentNodeIndex(ghostType),
							game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType)) < 70) {
						moves.put(ghostType,
								game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
										game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType),
										DM.PATH));
					} else {
						moves.put(ghostType, allMoves[rnd.nextInt(allMoves.length)]);
					}
				}
				if (ghostType == GHOST.SUE) {
					if (game.getGhostLastMoveMade(GHOST.INKY) != null) {
						if (game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
								game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType),
								DM.PATH) == game.getPacmanLastMoveMade()) {
							moves.put(ghostType,
									nextMoveNoRepeatGhost(game, game.getPacmanLastMoveMade(), ghostType, 30));
						} else {
							moves.put(ghostType,
									game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
											game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType),
											DM.PATH));

						}
					}
				} else {
					moves.put(ghostType,
							game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
									game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType), DM.PATH));

				}
			}
		}
		return moves;
	}
}
