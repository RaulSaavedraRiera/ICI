package es.ucm.fdi.ici.c2223.practica1.grupo08;

import java.awt.Color;
import java.io.Console;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

import pacman.controllers.PacmanController;
import pacman.game.Game;
import pacman.game.GameView;
import pacman.game.Constants;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;

public class MsPacMan extends PacmanController {
	
	public MsPacMan(){
		
		super();
		setName("MsPacMan de Pablo y Manu");
		setTeam("Grupo 08: Pablo y Manu");
		
	}
	
	// Probar a editar limites dependiendo de si hay al menos dos comestibles
	int chasingGhostLimit = 30;
	int aggressiveGhostLimit = 50;
	int edibleGhostLimit = 120;
	int ghostMidRangeLimit = 80;
	int powerPillTooCloseLimit = 45;
	int edibleGhostTimeLimit = 15;
	int ghostProximityLimit = 0; 	// No ha merecido la pena
	
	int jailIndex = 99999;
	ArrayList<Integer> unfoundCorners = new ArrayList<Integer>();
	ArrayList<Integer> foundCorners = new ArrayList<Integer>();
	
	
	int jailLimit = 50;
	int jailTimeLimit = 25;
	int foundCornerLimit = 40;
	
	int pacIsInCornerLimit = 10;
	
	private Random rnd = new Random();
	
	@Override public MOVE getMove(Game game, long timeDue) {
		
		// Solo una vez: Encuentra rincones y salida de la celda
		
		if (unfoundCorners.isEmpty()) {
			for(int i = 0; i < game.getActivePowerPillsIndices().length; i++) {
					unfoundCorners.add(game.getActivePowerPillsIndices()[i]);
			}
		}
		
		if (jailIndex == 99999 && game.getGhostLairTime(GHOST.BLINKY) <= 0) {
			jailIndex = game.getGhostCurrentNodeIndex(GHOST.BLINKY);
		}
		
		
		// Fantasmas fuera de la celda
		
		int ghostsOut = 0;
		for(GHOST ghostType : GHOST.values()) {
			if (game.getGhostLairTime(ghostType) <= 0)
				ghostsOut++;
		}
		
		// Fantasmas Cercanos
		
		ArrayList<Integer> ghostsInMidRange = new ArrayList<Integer>();
		for (GHOST ghostType : GHOST.values()) {
			if (game.getGhostLairTime(ghostType) <= 0 && !game.isGhostEdible(ghostType) && game.getApproximateShortestPathDistance(game.getGhostCurrentNodeIndex(ghostType),
					game.getPacmanCurrentNodeIndex(),
					game.getGhostLastMoveMade(ghostType)) < ghostMidRangeLimit) {
				ghostsInMidRange.add(game.getGhostCurrentNodeIndex(ghostType));
			}
		}
		
		
		// Marcar PowerPills / Rincones visitados
		
		if (unfoundCorners.size() > game.getNumberOfActivePowerPills()) {
			
			foundCorners.add(getNearestUnfoundCornerIndex(game));
			unfoundCorners.remove(unfoundCorners.indexOf(getNearestUnfoundCornerIndex(game)));
			
		}
		
		
		// -------------------------------------------------------------------------------------
		
		
		
		// 1. Huir de fantasmas muy cercanos (que no lo persiguen directo, no van en su mismo sentido)
		
		GHOST nearestGhost = getNearestAggressiveGhost(game, chasingGhostLimit);
		
		if (nearestGhost != null) {
			GameView.addLines(game, Color.RED, game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(nearestGhost));
			return game.getApproximateNextMoveAwayFromTarget(game.getPacmanCurrentNodeIndex(),
					game.getGhostCurrentNodeIndex(nearestGhost),
					game.getPacmanLastMoveMade(),
					Constants.DM.PATH);
		}
		
		
		
		// 2. Huir de la salida de la celda si hay un fantasma dentro al que le queda poco tiempo (y estamos cerca)
		
		if (jailIndex < 99999 && getNextGhostLeavingJailTime(game) < jailTimeLimit
				&& game.getShortestPathDistance(jailIndex, game.getPacmanCurrentNodeIndex()) < jailLimit) {
			
			GameView.addLines(game, Color.RED, game.getPacmanCurrentNodeIndex(), jailIndex);
			return game.getApproximateNextMoveAwayFromTarget(game.getPacmanCurrentNodeIndex(),
					jailIndex,
					game.getPacmanLastMoveMade(),
					Constants.DM.PATH);
			
		}
		
		
		
		// 3. Perseguir fantasma comestible hasta que baje demasiado el tiempo.
		
		nearestGhost = getNearestEdibleGhost(game, edibleGhostLimit);
		
		if (nearestGhost != null && (game.getGhostEdibleTime(nearestGhost) > edibleGhostTimeLimit || game.getGhostLastMoveMade(nearestGhost) == game.getPacmanLastMoveMade())) {
			GameView.addLines(game, Color.BLUE, game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(nearestGhost));
			return game.getApproximateNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),
					game.getGhostCurrentNodeIndex(nearestGhost),
					game.getPacmanLastMoveMade(),
					Constants.DM.PATH);
		}
		
		
		
		
		// (Si hay dos fantasmas, uno junto a otro, ir a por PowerPill). Al final, esto no ha merecido la pena. Iria aqui, y el 4. mas abajo

		/* 
		GHOST secondNearestGhost = null;
		nearestGhost = getNearestChasingGhost(game, aggressiveGhostLimit);
		if (nearestGhost != null && getNearestPowerPillIndex(game) < 99999) secondNearestGhost = getNearestGhostToGhost(game, nearestGhost, ghostProximityLimit);
		
		if (secondNearestGhost != null) {
			GameView.addLines(game, Color.CYAN, game.getPacmanCurrentNodeIndex(), getNearestPowerPillIndex(game));
			GameView.addLines(game, Color.CYAN, game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(nearestGhost));
			GameView.addLines(game, Color.CYAN, game.getGhostCurrentNodeIndex(nearestGhost), game.getGhostCurrentNodeIndex(secondNearestGhost));
			
			return game.getApproximateNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),
					getNearestPowerPillIndex(game),
					game.getPacmanLastMoveMade(),
					Constants.DM.PATH);
		}
		*/
		
		// 4. Si hay dos fantasmas cerca de PacMan, aunque no estén cerca uno del otro, ir a por PowerPill.
		
				if (ghostsInMidRange.size() >= 2 && getNearestPowerPillIndex(game) < 99999) {
					GameView.addLines(game, Color.CYAN, game.getPacmanCurrentNodeIndex(), getNearestPowerPillIndex(game));
					for (int i = 0; i < ghostsInMidRange.size(); i++)
							GameView.addLines(game, Color.CYAN, game.getPacmanCurrentNodeIndex(), ghostsInMidRange.get(i));
					return game.getApproximateNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),
							getNearestPowerPillIndex(game),
							game.getPacmanLastMoveMade(),
							Constants.DM.PATH);
				}
		
		
		
		// 5. Huir de PowerPills muy cercanas cuando no conviene (fantasmas lejos o comestibles, no hay al menos 3 fuera de la celda).
			
		if (getNearestPowerPillIndex(game) < 99999) {
			
			if (game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), getNearestPowerPillIndex(game)) < powerPillTooCloseLimit && (ghostsOut < 3 || ghostsInMidRange.size() < 1)) {
				GameView.addLines(game, Color.RED, game.getPacmanCurrentNodeIndex(), getNearestPowerPillIndex(game));
				return game.getApproximateNextMoveAwayFromTarget(game.getPacmanCurrentNodeIndex(),
						getNearestPowerPillIndex(game),
						game.getPacmanLastMoveMade(),
						Constants.DM.EUCLID);
			}
		}
		
		
		// 6. Huir de fantasmas agresivos medio-cercanos
		
		nearestGhost = getNearestChasingGhost(game, aggressiveGhostLimit);
		
		if (nearestGhost != null) {
			GameView.addLines(game, Color.RED, game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(nearestGhost));
			return game.getApproximateNextMoveAwayFromTarget(game.getPacmanCurrentNodeIndex(),
					game.getGhostCurrentNodeIndex(nearestGhost),
					game.getPacmanLastMoveMade(),
					Constants.DM.PATH);
		}
		
		
		
		// 7. Huir de esquinas / Rincones sin PowerPill cercanas
		
				if (!foundCorners.isEmpty() &&
						game.getApproximateShortestPathDistance(game.getPacmanCurrentNodeIndex(), getNearestFoundCornerIndex(game), game.getPacmanLastMoveMade()) < foundCornerLimit
						&& ghostsInMidRange.size() > 0) {
					GameView.addLines(game, Color.YELLOW, game.getPacmanCurrentNodeIndex(), getNearestFoundCornerIndex(game));
					return game.getApproximateNextMoveAwayFromTarget(game.getPacmanCurrentNodeIndex(),
							getNearestFoundCornerIndex(game),
							game.getPacmanLastMoveMade(),
							Constants.DM.EUCLID);
				}
		
		

		
		// 8. Si no hay fantasmas cerca, ir a por uno HASTA que esté medio-cerca. Probar más tarde a buscar parejas?
		
		
		if (ghostsOut >= 2) {
		
			nearestGhost = getNearestChasingGhost(game, 99999);
			
			if (nearestGhost != null) {

			GameView.addLines(game, Color.GREEN, game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(nearestGhost));
			return game.getApproximateNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),
					game.getGhostCurrentNodeIndex(nearestGhost),
					game.getPacmanLastMoveMade(),
					Constants.DM.PATH);
			}
		}
		
		
		// 9. RET hacia la pill pequeña más cercana
		
		return game.getApproximateNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),
				getNearestPillIndex(game),
				game.getPacmanLastMoveMade(),
				Constants.DM.PATH);
		
		// return MOVE.values()[rnd.nextInt(MOVE.values().length)];
	}

	
	
	// ----------------------------------------------------------------------------------------------
	
	
	

	private GHOST getNearestEdibleGhost(Game game, int limit) {
		GHOST ret = null;
		int closestGhostDist = limit;

		for (GHOST ghostType : GHOST.values()) {
			
			if (game.getGhostLairTime(ghostType) <= 0 && game.isGhostEdible(ghostType)) {
			
				int dist = game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghostType), game.getPacmanLastMoveMade());
				
				if (dist < closestGhostDist) {
					closestGhostDist = dist;
					ret = ghostType;
				}			
			}
		}
		
		return ret;
	}
	
	

	private GHOST getNearestChasingGhost(Game game, int limit) {
		
		GHOST ret = null;
		int closestGhostDist = limit;

		for (GHOST ghostType : GHOST.values()) {
			
			if (game.getGhostLairTime(ghostType) <= 0 && !game.isGhostEdible(ghostType)) {
			
				int dist = game.getShortestPathDistance(game.getGhostCurrentNodeIndex(ghostType), game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType));
				
				if (game.getGhostLairTime(ghostType) <= 0 && !game.isGhostEdible(ghostType) && dist < closestGhostDist) {
					closestGhostDist = dist;
					ret = ghostType;
				}			
			}
		}
		
		return ret;
	}
	
	
	
	// Enemy, but not chasing in behind PacMan. Instead, coming from the front, sides or wandering
private GHOST getNearestAggressiveGhost(Game game, int limit) {
		
		GHOST ret = null;
		int closestGhostDist = limit;

		for (GHOST ghostType : GHOST.values()) {
			
			if (game.getGhostLairTime(ghostType) <= 0 && !game.isGhostEdible(ghostType)) {
			
				int dist = game.getShortestPathDistance(game.getGhostCurrentNodeIndex(ghostType), game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType));
				
				if (game.getGhostLairTime(ghostType) <= 0 && !game.isGhostEdible(ghostType) && dist < closestGhostDist
						&& game.getGhostLastMoveMade(ghostType) != game.getPacmanLastMoveMade()) {
					closestGhostDist = dist;
					ret = ghostType;
				}			
			}
		}
		
		return ret;
	}



private GHOST getNearestGhostToGhost(Game game, GHOST fromGhost, int limit) {
	
	GHOST ret = null;
	int closestGhostDist = limit;

	for (GHOST ghostType : GHOST.values()) {
		
		if (game.getGhostLairTime(ghostType) <= 0 && ghostType != fromGhost) {
		
			int dist = game.getShortestPathDistance(game.getGhostCurrentNodeIndex(ghostType), game.getGhostCurrentNodeIndex(fromGhost));
			
			if (dist < closestGhostDist) {
				closestGhostDist = dist;
				ret = ghostType;
			}			
		}
	}
	
	return ret;
}
	
	
	
	private int getNearestPillIndex(Game game) {
		
		int nearestPillDist = 99999;
		int nearestPillIndex = 99999;
		
		for(int i = 0; i < game.getActivePillsIndices().length; i++) {
			if (game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getActivePillsIndices()[i]) < nearestPillDist) {
				nearestPillDist = game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getActivePillsIndices()[i]);
				nearestPillIndex = game.getActivePillsIndices()[i];
			}
		}
		
		return nearestPillIndex;
	}
	
	
	
private int getNearestPowerPillIndex(Game game) {
		
		int nearestPillDist = 99999;
		int nearestPillIndex = 99999;
		
		for(int i = 0; i < game.getActivePowerPillsIndices().length; i++) {
			if (game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getActivePowerPillsIndices()[i]) < nearestPillDist) {
				nearestPillDist = game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getActivePowerPillsIndices()[i]);
				nearestPillIndex = game.getActivePowerPillsIndices()[i];
			}
		}
		
		return nearestPillIndex;
	}



private int getNearestFoundCornerIndex(Game game) {
	
	int nearestCornerDist = 99999;
	int nearestCornerIndex = 99999;
	
	for(int i = 0; i < foundCorners.size(); i++) {
		if (game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), foundCorners.get(i)) < nearestCornerDist) {
			nearestCornerDist = game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), foundCorners.get(i));
			nearestCornerIndex = foundCorners.get(i);
		}
	}
	
	return nearestCornerIndex;
}


private int getNearestUnfoundCornerIndex(Game game) {
	
	int nearestCornerDist = 99999;
	int nearestCornerIndex = 99999;
	
	for(int i = 0; i < unfoundCorners.size(); i++) {
		if (game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), unfoundCorners.get(i)) < nearestCornerDist) {
			nearestCornerDist = game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), unfoundCorners.get(i));
			nearestCornerIndex = unfoundCorners.get(i);
		}
	}
	
	return nearestCornerIndex;
}



private GHOST getNextGhostLeavingJail(Game game) {
	
	GHOST ret = null;
	int retTime = 99999;
	
	for (GHOST ghostType : GHOST.values()) {
		if (game.getGhostLairTime(ghostType) > 0 && game.getGhostLairTime(ghostType) < retTime) {
			retTime = game.getGhostLairTime(ghostType);
			ret = ghostType;
		}
	}
	
	return ret;
}


private int getNextGhostLeavingJailTime(Game game) {
	
	int retTime = 99999;
	
	for (GHOST ghostType : GHOST.values()) {
		if (game.getGhostLairTime(ghostType) > 0 && game.getGhostLairTime(ghostType) < retTime) {
			retTime = game.getGhostLairTime(ghostType);
		}
	}
	
	return retTime;
}





}
